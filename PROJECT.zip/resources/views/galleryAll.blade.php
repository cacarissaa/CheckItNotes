{{--@extends('layout.app')--}}
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Template Name: Education Time
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Cek It Notes! | Gallery</title>
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <link rel="stylesheet" href="css/layout.css" type="text/css" />
    <script type="text/javascript" src="js//jquery.min.js"></script>
    <!-- prettyPhoto -->
    <link rel="stylesheet" href="css/prettyPhoto.css" type="text/css" />
    <script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $("a[rel^='prettyPhoto']").prettyPhoto({
                theme: 'dark_rounded',
                overlay_gallery: false,
                social_tools: false
            });
        });
    </script>
    <!-- / prettyPhoto -->
</head>
<body id="top">
<div class="wrapper row1">
    <div id="header" class="clear">
        <div class="fl_left">
            <a href=/material><img src="images/cekitnotes.png"></a>
            <p>A very useful website for all students in every Universities. It contains a lot of materials for various subjects and levels.</p>
        </div>
    </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper row2">
    <div id="topnav">
        <ul>
            <li><a href=/ >Home</a></li>
            <li><a href=/material>Material</a></li>
            <li class="active last"><a href=/gallery>Gallery</a></li>
        </ul>
        <div  class="clear"></div>
    </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper row4">
    <div id="container" class="clear">
        <!-- ####################################################################################################### -->
        <div id="gallery" class="clear">
            <div class="gallerycontainer clear">
                <div class="fl_left">
                    <h2 class="title">Latest Videos</h2>
                    <p>All videos about education, which is teaching, university and tips videos.</p>
                </div>
                <div class="fl_right">
                    <ul>
                        <li><a href="http://www.youtube.com/watch?v=TIMmp6XWiG0" rel="prettyPhoto[gallery1]" title="Oxford University - How To Apply- Undergraduate Admissions"><img src="images/video1.jpg" alt="" /></a></li>
                        <li class="last"><a href="https://www.youtube.com/watch?v=WpXMlZ5WipI&t=65s" rel="prettyPhoto[gallery1]" title="Top Down Parsing"><img src="images/video2.jpg" alt="" /></a></li>
                        <li><a href="https://www.youtube.com/watch?v=I1iRyigxdVo&t=1s" rel="prettyPhoto[gallery1]" title="Tutorial Pendaftaran Online BINUS University"><img src="images/video3.jpg" alt="" /></a></li>
                        <li class="last"><a href="https://www.youtube.com/watch?v=7TF00hJI78Y&t=1s" rel="prettyPhoto[gallery1]" title="PHP Programming"><img src="images/video4.jpg" alt="" /></a></li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- ####################################################################################################### -->
        <!-- ####################################################################################################### -->
        <div class="clear"></div>
    </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
    <div id="copyright" class="clear">
        <p class="fl_left">Copyright &copy; 2018 - Binus University - CheckItNotes!</p>
    </div>
</div>
</div>
</body>
</html>