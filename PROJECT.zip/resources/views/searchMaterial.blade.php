<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Template Name: Education Time
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Check It Notes! | Material</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <link rel="stylesheet" href="css/layout.css" type="text/css" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/form/font-awesome.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/form/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->
</head>

<div id="top">
    <div class="wrapper row1">
        <div id="header" class="clear">
            <div class="fl_left">
                <a href=/material><img src="images/cekitnotes.png"></a>
                <p>A very useful website for all students in every Universities. It contains a lot of materials for various subjects and levels.</p>
            </div>
        </div>
    </div>
    <!-- ####################################################################################################### -->
    <div class="wrapper row2">
        <div id="topnav">
            <ul>
                <li><a href=/ >Home</a></li>
                <li class="active"><a href=/material>Material</a></li>
                <li class="last"><a href=/gallery>Gallery</a></li>
            </ul>
            <div  class="clear"></div>
        </div>
    </div>
    <!-- ####################################################################################################### -->
    <div class="wrapper row4">
        <div class="container-contact100">
            <div class="wrap-contact100">
                <form class="contact100-form validate-form">

                    @if(count($temp))
				<span class="contact100-form-title">
					Your Material!
				</span>
                    <div id="material">
                        @foreach($temp as $t)
                            <p> <img src="images/fileLogo.png"> <b>{{$t->contentFile}}</b> </p>
                            <a href="/searchMaterial/content/{{$t->contentFile}}.docx" class="btn btn-large pull-right"><i class="icon-download-alt"> Download</i> </a>
                            <p> <br> </p>
                        @endforeach

                        {{ $temp->links() }}

                    </div>
                        @else
                        <span class="contact100-form-title">
					        Your material not found.
				        </span>
                        @endif
                </form>
            </div>
            </div>
        </div>

        <div id="dropDownSelect1"></div>

        <!--================================================================php===============================-->
        <script src="js/form/jquery-3.2.1.min.js"></script>
        <!--===============================================================================================-->
        <script src="js/form/animsition.min.js"></script>
        <!--==========js/popper.js"></script>
        <script src="../form/vendor/bootstrap/js/bootstrap.min.js"></script>
        <!--===============================================================================================-->
        <script src="js/form/select2.min.js"></script>
        <script>
            $(".selection-2").select2({
                minimumResultsForSearch: 20,
                dropdownParent: $('#dropDownSelect1')
            });
        </script>
        <!--===============================================================================================-->
        <script src="js/form/moment.min.js"></script>
        <script src="js/form/daterangepicker.js"></script>
        <!--===============================================================================================-->
        <script src="js/form/countdowntime.js"></script>
        <!--===============================================================================================-->
        <script src="js/form/main.js"></script>

        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'UA-23581568-13');
        </script>
    </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
    <div id="copyright" class="clear">
        <p class="fl_left">Copyright &copy; 2018 - Binus University - CheckItNotes!</p>
    </div>
</div>
</body>
</html>