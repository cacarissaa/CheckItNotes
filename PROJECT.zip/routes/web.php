<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::get('/material', function()
{
    return view('material');
});

Route::get('/gallery', function()
{
    return view('gallery');
});

Route::get('/galleryAll', function()
{
    return view('galleryAll');
});

Route::get('/searchMaterial', 'ContentController@index')->name('searchMaterial');

Route::get('/searchMaterial/content/{file}', 'ContentController@getDownload');

Route::get('/searchMaterial', 'ContentController@searchContent')->name('searchMaterial');

//Route::get('/searchMaterial', 'ContentController@searchAll')->name('searchMaterial');
