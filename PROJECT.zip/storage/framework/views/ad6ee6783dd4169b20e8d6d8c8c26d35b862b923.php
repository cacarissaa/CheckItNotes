<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Template Name: Education Time
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Cek It Notes! | Material</title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <link rel="stylesheet" href="css/layout.css" type="text/css" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/form/font-awesome.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/form/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="css/util.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <!--===============================================================================================-->
</head>

<div id="top">
    <div class="wrapper row1">
        <div id="header" class="clear">
            <div class="fl_left">
                <a href=/material><img src="images/cekitnotes.png"></a>
                <p>A very useful website for all students in every Universities. It contains a lot of materials for various subjects and levels.</p>
            </div>
        </div>
    </div>
    <!-- ####################################################################################################### -->
    <div class="wrapper row2">
        <div id="topnav">
            <ul>
                <li><a href=/ >Home</a></li>
                <li class="active"><a href=/material>Material</a></li>
                <li class="last"><a href=/gallery>Gallery</a></li>
            </ul>
            <div  class="clear"></div>
        </div>
    </div>
    <!-- ####################################################################################################### -->
    <div class="wrapper row4">
        <div class="container-contact100">
            <div class="wrap-contact100">
                <form class="contact100-form validate-form" action=/searchMaterial name='form1' id='formCombo'>
                    <?php echo e(csrf_field()); ?>

				<span class="contact100-form-title">
					Search your material!
				</span>

                    <div class="wrap-input100 validate-input" data-validate="Keyword is required">
                        <span class="label-input100">Your Material</span>
                        <input class="input100" type="text" name="word" placeholder="Enter your material keyword">
                        <span class="focus-input100"></span>
                    </div>

                    <div class="wrap-input100 input100-select">
                        <span class="label-input100">University</span>
                        <div>
                            <select class="selection-2" name="univ" id="univ" onchange="showMajor()">
                                <option value='' selected>Choose University</option>
                                    <?php
                                    include "combo_major.php";
                                    include "connection.php";

                                    $queryUniv=mysqli_query($link, "select * from universities order by id asc ");

                                    while($r = mysqli_fetch_array($queryUniv))
                                        {
                                            echo "<option value='$r[id]'>$r[univName]</option>";
                                        }
                                ?>
                            </select>
                        </div>
                        <span class="focus-input100"></span>
                    </div>
                    <div class="wrap-input100 input100-select">
                        <span class="label-input100">Major</span>
                        <div>
                            <select class="selection-2" name="major" id="major">
                                <option value=''>Select Major</option>
                            </select>
                        </div>
                        <span class="focus-input100"></span>
                    </div>

                    <div class="container-contact100-form-btn">
                        <div class="wrap-contact100-form-btn">
                            <div class="contact100-form-bgbtn"></div>
                            <script type="text/javascript">
                                function IsEmpty(){
                                    if(document.forms['form1'].word.value === "")
                                    {
                                        alert("Material can't be empty!");
                                        return false;
                                    }
                                    if(document.forms['form1'].univ.value === "")
                                    {
                                        alert("University can't be empty!");
                                        return false;
                                    }
                                    else if(document.forms['form1'].major.value === "")
                                    {
                                        alert("Major can't be empty!");
                                        return false;
                                    }
                                    return true;
                                }
                            </script>
                            <button class="contact100-form-btn" type="submit" onclick="return IsEmpty();">
							<span class="glyphicon glyphicon-search">
								Search
								<i class="fa fa-long-arrow-right m-l-7" aria-hidden="true"></i>
							</span>
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>



        <div id="dropDownSelect1"></div>
        <!--===============================================================================================-->
        <script src="js/form/jquery-3.2.1.min.js"></script>
        <!--===============================================================================================-->
        <script src="js/form/animsition.min.js"></script>
        <!--==========js/popper.js"></script>
        <script src="../form/vendor/bootstrap/js/bootstrap.min.js"></script>
        <!--===============================================================================================-->
        <script src="js/form/select2.min.js"></script>
        <script>
            $(".selection-2").select2({
                minimumResultsForSearch: 20,
                dropdownParent: $('#dropDownSelect1')
            });
        </script>
        <!--===============================================================================================-->
        <script src="js/form/moment.min.js"></script>
        <script src="js/form/daterangepicker.js"></script>
        <!--===============================================================================================-->
        <script src="js/form/countdowntime.js"></script>
        <!--===============================================================================================-->
        <script src="js/form/main.js"></script>

        <!-- Global site tag (gtag.js) - Google Analytics -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());

            gtag('config', 'UA-23581568-13');
        </script>
    </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper">
    <div id="copyright" class="clear">
        <p class="fl_left">Copyright &copy; 2018 - Binus University - CheckItNotes!</p>
    </div>
</div>
</body>
</html>