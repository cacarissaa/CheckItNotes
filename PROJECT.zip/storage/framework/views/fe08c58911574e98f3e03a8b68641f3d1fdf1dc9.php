
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!--
Template Name: Education Time
Author: <a href="http://www.os-templates.com/">OS Templates</a>
Author URI: http://www.os-templates.com/
Licence: Free to use under our free template licence terms
Licence URI: http://www.os-templates.com/template-terms
-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Cek It Notes!</title>
  <!--===============================================================================================-->
  <link rel="stylesheet" type="text/css" href="css/util.css">
  <link rel="stylesheet" type="text/css" href="css/main.css">
  <!--===============================================================================================-->
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  <link rel="stylesheet" href="css/layout.css" type="text/css" />
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <!-- liteAccordion is Homepage Only -->
  <link rel="stylesheet" href="css/liteaccordion.css" type="text/css" />
</head>
<body id="top">
<div class="wrapper row1">
  <div id="header" class="clear" >
    <div class="fl_left">
      <a href=/material><img src="images/cekitnotes.png"></a>
      <p>A very useful website for all students in every Universities. It contains a lot of materials for various subjects and levels.</p>
    </div>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper row2">
  <div id="topnav">
    <ul>
      <li class="active"><a href=/ >Home</a></li>
      <li><a href=/material>Material</a></li>
      <li class="last"><a href=/gallery>Gallery</a></li>
    </ul>
    <div  class="clear"></div>
  </div>
</div>
<!-- ####################################################################################################### -->
<div class="wrapper row3">
  <div id="featured_slide">
    <!-- ####################################################################################################### -->
    <ol>
      <li>
        <h2><span>Slide 1</span></h2>
        <div><img src="images/a.jpg" alt="" /></div>
      </li>
      <li>
        <h2><span>Slide 2</span></h2>
        <div><img src="images/b.jpg" alt="" /></div>
      </li>
      <li>
        <h2><span>Slide 3</span></h2>
        <div><img src="images/c.jpg" alt="" /></div>
      </li>
      <li>
        <h2><span>Slide 4</span></h2>
        <div><img src="images/d.jpg" alt="" /></div>
      </li>
      <li>
        <h2><span>Slide 5</span></h2>
        <div><img src="images/e.jpg" alt="" /></div>
      </li>
    </ol>
    <!-- ####################################################################################################### -->
  </div>
</div>
<!-- ####################################################################################################### -->

<!-- ####################################################################################################### -->
<div class="wrapper">
  <div id="copyright" class="clear">
    <p class="fl_left">Copyright &copy; 2018 - Binus University - CheckItNotes!</p>
  </div>
</div>
<!-- liteAccordion is Homepage Only -->
<script type="text/javascript" src="js/liteaccordion.jquery.min.js"></script>
<script type="text/javascript">
    $("#featured_slide").liteAccordion({
        theme: "os-tpl",
        containerWidth: 960, // fixed (px)
        containerHeight: 360, // fixed (px) - overall height of the slider
        headerWidth: 48, // fixed (px) - slide spine title
        firstSlide: 1, // displays slide (n) on page load
        activateOn: "click", // click or mouseover
        autoPlay: false, // automatically cycle through slides
        pauseOnHover: true, // pause slides on hover
        rounded: false, // square or rounded corners
        enumerateSlides: true, // put numbers on slides
        slideSpeed: 800, // slide animation speed
        cycleSpeed: 6000, // time between slide cycles
    });
</script>
</body>
</html>